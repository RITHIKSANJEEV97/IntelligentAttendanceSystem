package android.support.v4.view;

import android.view.View;

public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    public void onAnimationStart(View view) {
    }

    public void onAnimationEnd(View view) {
    }

    public void onAnimationCancel(View view) {
    }
}
