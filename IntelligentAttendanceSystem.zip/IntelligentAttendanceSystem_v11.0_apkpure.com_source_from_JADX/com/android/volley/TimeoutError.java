package com.android.volley;

public class TimeoutError extends VolleyError {
}
