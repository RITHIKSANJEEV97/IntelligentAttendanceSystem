package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class scheduler extends AppCompatActivity implements OnItemLongClickListener {
    static final /* synthetic */ boolean $assertionsDisabled = (!scheduler.class.desiredAssertionStatus());
    Activity activity = this;
    ArrayAdapter adapter;
    ListView listView;
    ArrayList<String> subs;
    ArrayList<String> subx;
    ArrayList<String> times;

    class C03661 implements OnClickListener {
        C03661() {
        }

        public void onClick(View view) {
            scheduler.this.startActivity(new Intent(scheduler.this.getBaseContext(), make_schedule.class));
        }
    }

    class C03683 implements DialogInterface.OnClickListener {
        C03683() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_scheduler);
        FloatingActionButton fab = (FloatingActionButton) findViewById(C0319R.id.fab_sch);
        if ($assertionsDisabled || fab != null) {
            fab.setOnClickListener(new C03661());
            this.subs = new ArrayList();
            this.times = new ArrayList();
            this.subx = new ArrayList();
            this.listView = (ListView) findViewById(C0319R.id.schedulerList);
            loadSchedules();
            this.listView.setOnItemLongClickListener(this);
            return;
        }
        throw new AssertionError();
    }

    private void loadSchedules() {
        this.subs.clear();
        this.times.clear();
        Cursor cursor = AppBase.handler.execQuery("SELECT * FROM SCHEDULE ORDER BY subject");
        if (cursor == null || cursor.getCount() == 0) {
            Toast.makeText(getBaseContext(), "No Schedules Available", 1).show();
        } else {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                this.subx.add(cursor.getString(1));
                this.subs.add(cursor.getString(1) + "\nfor " + cursor.getString(0) + "\nat " + cursor.getString(2) + " : " + cursor.getString(3));
                this.times.add(cursor.getString(2));
                cursor.moveToNext();
            }
        }
        this.listView.setAdapter(new ArrayAdapter(getBaseContext(), 17367043, this.subs));
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long id) {
        Builder alert = new Builder(this.activity);
        alert.setTitle("Delete Schedule?");
        alert.setMessage("Do you want to delete this schedule ?");
        alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DELETE FROM SCHEDULE WHERE subject = '" + ((String) scheduler.this.subx.get(position)) + "' AND timex = '" + ((String) scheduler.this.times.get(position)) + "'")) {
                    Toast.makeText(scheduler.this.getBaseContext(), "Deleted", 1).show();
                    scheduler.this.loadSchedules();
                } else {
                    Toast.makeText(scheduler.this.getBaseContext(), "Failed", 1).show();
                    scheduler.this.loadSchedules();
                }
                dialog.dismiss();
            }
        });
        alert.setNegativeButton("NO", new C03683());
        alert.show();
        return true;
    }

    public void refresh(MenuItem item) {
        loadSchedules();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(C0319R.menu.scheduler_menu, menu);
        return true;
    }
}
