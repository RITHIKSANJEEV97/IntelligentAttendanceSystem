package creations.raghul.smartattendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.ArrayList;

public class make_schedule extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!make_schedule.class.desiredAssertionStatus());
    ArrayAdapter adapterSpinner;
    Spinner classSelect;
    Spinner daySelect;
    ArrayAdapter days;

    class C03621 implements OnClickListener {
        C03621() {
        }

        public void onClick(View v) {
            make_schedule.this.saveSchedule(v);
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.schedule_create);
        this.classSelect = (Spinner) findViewById(C0319R.id.classSelector);
        this.daySelect = (Spinner) findViewById(C0319R.id.daySelector);
        this.adapterSpinner = new ArrayAdapter(this, 17367049, AppBase.divisions);
        if ($assertionsDisabled || this.classSelect != null) {
            this.classSelect.setAdapter(this.adapterSpinner);
            ArrayList<String> weekdays = new ArrayList();
            weekdays.add("MONDAY");
            weekdays.add("TUESDAY");
            weekdays.add("WEDNESDAY");
            weekdays.add("THURSDAY");
            weekdays.add("FRIDAY");
            weekdays.add("SATURDAY");
            weekdays.add("SUNDAY");
            this.days = new ArrayAdapter(this, 17367049, weekdays);
            if ($assertionsDisabled || this.classSelect != null) {
                this.daySelect.setAdapter(this.days);
                Button btn = (Button) findViewById(C0319R.id.saveBUTTON_SCHEDULE);
                if ($assertionsDisabled || btn != null) {
                    btn.setOnClickListener(new C03621());
                    return;
                }
                throw new AssertionError();
            }
            throw new AssertionError();
        }
        throw new AssertionError();
    }

    private void saveSchedule(View v) {
        String daySelected = this.daySelect.getSelectedItem().toString();
        String classSelected = this.classSelect.getSelectedItem().toString();
        String subject = ((EditText) findViewById(C0319R.id.subjectName)).getText().toString();
        if (subject.length() < 2) {
            Toast.makeText(getBaseContext(), "Enter Valid Subject Name", 0).show();
            return;
        }
        TimePicker timePicker = (TimePicker) findViewById(C0319R.id.timePicker);
        int hour = timePicker.getCurrentHour().intValue();
        String sql = "INSERT INTO SCHEDULE VALUES('" + classSelected + "','" + subject + "','" + hour + ":" + timePicker.getCurrentMinute().intValue() + "','" + daySelected + "');";
        Log.d("Schedule", sql);
        if (AppBase.handler.execAction(sql)) {
            Toast.makeText(getBaseContext(), "Scheduling Done", 1).show();
            finish();
            return;
        }
        Toast.makeText(getBaseContext(), "Failed To Schedule", 1).show();
    }
}
