package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationCompat.BigTextStyle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.DefaultRetryPolicy;
import java.util.ArrayList;

public class gridAdapter extends BaseAdapter {
    public static Activity activity;
    Context cont;
    ArrayList names;

    class C03521 implements OnClickListener {
        C03521() {
        }

        public void onClick(View v) {
            new createRequest().show(gridAdapter.activity.getFragmentManager(), "Select");
        }
    }

    class C03542 implements OnClickListener {

        class C03531 implements DialogInterface.OnClickListener {
            C03531() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03542() {
        }

        public void onClick(View v) {
            AlertDialog alertDialog = new Builder(gridAdapter.this.cont).create();
            alertDialog.setTitle("Update Required");
            alertDialog.setMessage("Skcet To Do List is still under construction. Please Wait for the next Update. If an update is available for this app. Please Update to start using SKCET TO DO LIST");
            alertDialog.setButton(-3, "OK", new C03531());
            alertDialog.show();
        }
    }

    class C03563 implements OnClickListener {

        class C03551 implements DialogInterface.OnClickListener {
            C03551() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03563() {
        }

        public void onClick(View v) {
            AlertDialog alertDialog = new Builder(gridAdapter.this.cont).create();
            alertDialog.setTitle("Update Required");
            alertDialog.setMessage("Notes is still under construction. Please Wait for the next Update. If an update is available for this app. Please Update to start using Notes");
            alertDialog.setButton(-3, "OK", new C03551());
            alertDialog.show();
        }
    }

    class C03574 implements OnClickListener {
        C03574() {
        }

        public void onClick(View v) {
            gridAdapter.activity.startActivity(new Intent(gridAdapter.activity, alita.class));
        }
    }

    class C03585 implements OnClickListener {
        C03585() {
        }

        public void onClick(View v) {
            gridAdapter.activity.startActivity(new Intent(gridAdapter.activity, profile_activity.class));
        }
    }

    public static class createRequest extends DialogFragment {
        static final /* synthetic */ boolean $assertionsDisabled = (!gridAdapter.class.desiredAssertionStatus());

        class C03591 implements DialogInterface.OnClickListener {
            C03591() {
            }

            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        }

        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        }

        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Builder builder = new Builder(getActivity());
            View v = getActivity().getLayoutInflater().inflate(C0319R.layout.pick_period, null);
            final DatePicker datePicker = (DatePicker) v.findViewById(C0319R.id.datePicker);
            final EditText hour = (EditText) v.findViewById(C0319R.id.periodID);
            final Spinner spn = (Spinner) v.findViewById(C0319R.id.spinnerSubject);
            ArrayList<String> subs = new ArrayList();
            subs.add("Not Specified");
            Cursor cr = AppBase.handler.execQuery("SELECT DISTINCT sub FROM NOTES");
            if (cr != null) {
                cr.moveToFirst();
                while (!cr.isAfterLast()) {
                    subs.add(cr.getString(0));
                    Log.d("gridAdapter.class", "Cached " + cr.getString(0));
                    cr.moveToNext();
                }
            } else {
                Log.d("gridAdapter.class", "No SUBS" + cr.getString(0));
            }
            ArrayAdapter<String> adapterSpinner = new ArrayAdapter(gridAdapter.activity, 17367049, subs);
            if ($assertionsDisabled || spn != null) {
                spn.setAdapter(adapterSpinner);
                builder.setView(v).setPositiveButton("Enter", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String date = datePicker.getYear() + "-" + (datePicker.getMonth() + 1) + "-" + datePicker.getDayOfMonth();
                        Cursor cr = AppBase.handler.execQuery("SELECT title FROM NOTES where sub = '" + spn.getSelectedItem().toString() + "'");
                        String subnames = "";
                        if (cr != null) {
                            cr.moveToFirst();
                            while (!cr.isAfterLast()) {
                                subnames = subnames + cr.getString(0) + "\n";
                                cr.moveToNext();
                            }
                        }
                        gridAdapter.makeNotification(subnames);
                        Cursor cursor = AppBase.handler.execQuery("SELECT * FROM ATTENDANCE WHERE datex = '" + date + "' AND hour = " + hour.getText() + ";");
                        if (cursor == null || cursor.getCount() == 0) {
                            Intent launchinIntent = new Intent(AppBase.activity, attendanceActivity.class);
                            launchinIntent.putExtra("DATE", date);
                            launchinIntent.putExtra("PERIOD", hour.getText().toString());
                            AppBase.activity.startActivity(launchinIntent);
                            return;
                        }
                        Toast.makeText(createRequest.this.getActivity(), "Period Already Added", 1).show();
                    }
                }).setNegativeButton("Cancel", new C03591());
                return builder.create();
            }
            throw new AssertionError();
        }
    }

    public gridAdapter(Activity activity, ArrayList names, Context conttt) {
        activity = activity;
        this.names = names;
        this.cont = conttt;
    }

    public int getCount() {
        return this.names.size();
    }

    public Object getItem(int position) {
        return this.names.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View v, ViewGroup parent) {
        if (v == null) {
            v = LayoutInflater.from(activity).inflate(C0319R.layout.grid_layout, null);
        }
        TextView textView = (TextView) v.findViewById(C0319R.id.namePlacer);
        ImageView imageView = (ImageView) v.findViewById(C0319R.id.imageHolder);
        Animation anim;
        if (this.names.get(position).toString().equals("Mark Absenties (Attendance)")) {
            imageView.setImageResource(C0319R.drawable.ic_attendance);
            v.setOnClickListener(new C03521());
            anim = new ScaleAnimation(0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 1, 0.5f, 1, 0.5f);
            anim.setFillAfter(true);
            anim.setDuration(2000);
            anim.setRepeatMode(-1);
            anim.setRepeatCount(-1);
            imageView.startAnimation(anim);
        } else if (this.names.get(position).toString().equals("Skcet To Do List")) {
            imageView.setImageResource(C0319R.drawable.ic_schedule);
            v.setOnClickListener(new C03542());
            anim = new ScaleAnimation(0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 1, 0.5f, 1, 0.5f);
            anim.setFillAfter(true);
            anim.setDuration(2000);
            anim.setRepeatMode(-1);
            anim.setRepeatCount(-1);
            imageView.startAnimation(anim);
        } else if (this.names.get(position).toString().equals("NOTES")) {
            imageView.setImageResource(C0319R.drawable.ic_notes);
            v.setOnClickListener(new C03563());
            anim = new ScaleAnimation(0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 1, 0.5f, 1, 0.5f);
            anim.setFillAfter(true);
            anim.setDuration(2000);
            anim.setRepeatMode(-1);
            anim.setRepeatCount(-1);
            imageView.startAnimation(anim);
        } else if (this.names.get(position).toString().equals("Artificial Intelligence")) {
            imageView.setImageResource(C0319R.drawable.ic_alita);
            v.setOnClickListener(new C03574());
            anim = new ScaleAnimation(0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 1, 0.5f, 1, 0.5f);
            anim.setFillAfter(true);
            anim.setDuration(2000);
            anim.setRepeatMode(-1);
            anim.setRepeatCount(-1);
            imageView.startAnimation(anim);
        } else if (this.names.get(position).toString().equals("Students Area")) {
            imageView.setImageResource(C0319R.drawable.ic_profile);
            v.setOnClickListener(new C03585());
            anim = new ScaleAnimation(0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 0.95f, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT, 1, 0.5f, 1, 0.5f);
            anim.setFillAfter(true);
            anim.setDuration(2000);
            anim.setRepeatMode(-1);
            anim.setRepeatCount(-1);
            imageView.startAnimation(anim);
        }
        textView.setText(this.names.get(position).toString());
        return v;
    }

    public static void makeNotification(String userIntrouble) {
        Log.d("NOTIFICATION", "Building..........");
        PendingIntent pIntent = PendingIntent.getActivity(activity, 0, new Intent(activity.getApplicationContext(), noteActivity.class), 0);
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(activity.getBaseContext());
        Notification noti = new NotificationCompat.Builder(activity.getBaseContext()).setTicker("Attendance!").setContentTitle("Raghul'S Attendance App is Running").setSmallIcon(C0319R.drawable.ic_schedule).setStyle(new BigTextStyle().bigText(userIntrouble)).setContentIntent(pIntent).build();
        noti.contentIntent = pIntent;
        noti.flags = 16;
        Activity activity = activity;
        Activity activity2 = activity;
        ((NotificationManager) activity.getSystemService("notification")).notify(0, noti);
    }
}
