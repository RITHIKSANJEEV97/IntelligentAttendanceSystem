package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.support.v4.app.NotificationCompat;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class listAdapter extends BaseAdapter {
    Activity activity;
    ArrayList<Boolean> attendanceList;
    int car;
    CheckBox checkBox;
    ArrayList<String> cont;
    Context contt;
    databaseHandler handler = AppBase.handler;
    ArrayList<String> nameList;
    String querry;
    ArrayList<String> registers;

    public listAdapter(Activity activity, ArrayList<String> nameList, ArrayList<String> reg, ArrayList<String> Cont, Context contt) {
        this.nameList = nameList;
        this.activity = activity;
        this.registers = reg;
        this.cont = Cont;
        this.contt = contt;
        this.attendanceList = new ArrayList();
        for (int i = 0; i < nameList.size(); i++) {
            this.attendanceList.add(new Boolean(true));
        }
    }

    public int getCount() {
        return this.nameList.size();
    }

    public Object getItem(int position) {
        return this.nameList.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View v, ViewGroup parent) {
        if (v == null) {
            v = LayoutInflater.from(this.activity).inflate(C0319R.layout.list_ele, null);
        }
        final int pos = position;
        ((TextView) v.findViewById(C0319R.id.attendanceName)).setText((CharSequence) this.nameList.get(position));
        this.checkBox = (CheckBox) v.findViewById(C0319R.id.attMarker);
        if (this.car == 1) {
            this.checkBox.setChecked(false);
        } else {
            this.checkBox.setChecked(true);
        }
        this.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                listAdapter.this.attendanceList.set(pos, Boolean.valueOf(b));
            }
        });
        return v;
    }

    public void selectedAll() {
        this.car = 0;
        for (int i = 0; i < this.nameList.size(); i++) {
            this.attendanceList.set(i, Boolean.valueOf(true));
        }
    }

    public void deselectedAll() {
        this.car = 1;
        for (int i = 0; i < this.nameList.size(); i++) {
            this.attendanceList.set(i, Boolean.valueOf(false));
        }
    }

    public void saveAll() {
        String names = new String();
        String namess = new String();
        for (int i = 0; i < this.nameList.size(); i++) {
            int sts;
            if (((Boolean) this.attendanceList.get(i)).booleanValue()) {
                sts = 1;
            } else {
                sts = 0;
            }
            String qu = "INSERT INTO ATTENDANCE VALUES('" + attendanceActivity.time + "'," + attendanceActivity.period + ",'" + ((String) this.registers.get(i)) + "'," + sts + ");";
            try {
                Cursor ccr = AppBase.handler.execQuery("Select * from sendmsg;");
                ccr.moveToFirst();
                if (!ccr.isAfterLast() && sts == 0) {
                    SmsManager sm = SmsManager.getDefault();
                    String quii = "Select contact,name from student where regno = " + ((String) this.registers.get(i)).toString();
                    try {
                        sm.sendTextMessage("+91" + ((String) this.cont.get(i)), null, "Your Child " + ((String) this.nameList.get(i)) + " (" + ((String) this.registers.get(i)).toString() + ") has not attended period no : " + attendanceActivity.period.toString() + " today", null, null);
                    } catch (Exception e) {
                        Log.v("Messaging", e.toString());
                        Toast.makeText(this.contt, "Message Sending failed", 1).show();
                    }
                }
            } catch (Exception e2) {
            }
            AppBase.handler.execAction(qu);
        }
        try {
            registeronline();
        } catch (Exception e3) {
            Toast.makeText(this.contt, e3.toString(), 1).show();
        }
        this.activity.finish();
    }

    void registeronline() {
        final ProgressDialog pb = new ProgressDialog(this.contt);
        pb.setMessage("Updating on Server");
        pb.show();
        Volley.newRequestQueue(this.contt).add(new StringRequest(1, Constants.urlw, new Listener<String>() {
            public void onResponse(String response) {
                pb.dismiss();
                try {
                    JSONObject jb = new JSONObject(response);
                    Toast.makeText(listAdapter.this.contt, jb.getString(NotificationCompat.CATEGORY_MESSAGE), 1).show();
                    if (jb.getString(NotificationCompat.CATEGORY_MESSAGE).equals("Injection Successful")) {
                        try {
                            AppBase.handler.execAction("DELETE FROM attendance;");
                        } catch (Exception e) {
                            Toast.makeText(listAdapter.this.contt, "Error while Deleting from local database", 1).show();
                        }
                    }
                } catch (JSONException e2) {
                    Toast.makeText(listAdapter.this.contt, "Error on creating JSON", 1).show();
                }
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError error) {
                pb.dismiss();
                Toast.makeText(listAdapter.this.contt, "Network Error", 1).show();
            }
        }) {
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap();
                listAdapter.this.querry = "";
                Cursor cursorx = listAdapter.this.handler.execQuery("SELECT * FROM ATTENDANCE");
                if (!(cursorx == null || cursorx.getCount() == 0)) {
                    cursorx.moveToFirst();
                    while (!cursorx.isAfterLast()) {
                        listAdapter.this.querry += "insert into skcet values('" + cursorx.getString(0) + "'," + cursorx.getString(1) + ",'" + cursorx.getString(2) + "'," + cursorx.getString(3) + ");|";
                        cursorx.moveToNext();
                    }
                }
                params.put("querry", listAdapter.this.querry);
                params.put("querry2", "1");
                return params;
            }
        });
    }
}
