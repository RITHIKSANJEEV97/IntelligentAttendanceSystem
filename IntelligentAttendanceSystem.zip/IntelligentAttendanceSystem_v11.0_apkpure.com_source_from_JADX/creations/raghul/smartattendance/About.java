package creations.raghul.smartattendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.RelativeLayout;

public class About extends AppCompatActivity {
    Animation anim1;
    Animation anim2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_about);
        moveViewToScreenCenter(findViewById(C0319R.id.names));
        moveIcon(findViewById(C0319R.id.imageViewAbout));
    }

    private void moveIcon(View view) {
        int[] originalPos = new int[2];
        view.getLocationOnScreen(originalPos);
        this.anim2 = new TranslateAnimation(0.0f, 0.0f, 0.0f, (float) (originalPos[1] + 100));
        this.anim2.setDuration(2000);
        this.anim2.setFillAfter(true);
        view.startAnimation(this.anim2);
    }

    private void moveViewToScreenCenter(View view) {
        RelativeLayout root = (RelativeLayout) findViewById(C0319R.id.ctr);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int statusBarOffset = dm.heightPixels - root.getMeasuredHeight();
        int[] originalPos = new int[2];
        view.getLocationOnScreen(originalPos);
        int xDest = (dm.widthPixels / 2) - (view.getMeasuredWidth() / 2);
        this.anim1 = new TranslateAnimation(0.0f, 0.0f, 0.0f, (float) (((((dm.heightPixels / 2) - (view.getMeasuredHeight() / 2)) - statusBarOffset) - originalPos[1]) + Callback.DEFAULT_SWIPE_ANIMATION_DURATION));
        this.anim1.setDuration(1500);
        this.anim1.setFillAfter(true);
        view.startAnimation(this.anim1);
    }
}
