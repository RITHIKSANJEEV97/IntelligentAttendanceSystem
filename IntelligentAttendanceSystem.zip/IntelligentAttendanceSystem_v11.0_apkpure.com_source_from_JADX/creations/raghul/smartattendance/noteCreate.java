package creations.raghul.smartattendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class noteCreate extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!noteCreate.class.desiredAssertionStatus());
    EditText body;
    Spinner spinner;
    EditText title;

    class C03651 implements OnClickListener {
        C03651() {
        }

        public void onClick(View v) {
            noteCreate.this.saveData();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.note_create);
        Button btn = (Button) findViewById(C0319R.id.noteSaveButton);
        if ($assertionsDisabled || btn != null) {
            btn.setOnClickListener(new C03651());
            this.spinner = (Spinner) findViewById(C0319R.id.pinSpinner);
            ArrayAdapter<String> adapterSpinner = new ArrayAdapter(this, 17367049, AppBase.divisions);
            if ($assertionsDisabled || this.spinner != null) {
                this.spinner.setAdapter(adapterSpinner);
                return;
            }
            throw new AssertionError();
        }
        throw new AssertionError();
    }

    private void saveData() {
        this.title = (EditText) findViewById(C0319R.id.noteTitle);
        this.body = (EditText) findViewById(C0319R.id.noteBody);
        if (AppBase.handler.execAction(" INSERT INTO NOTES(title,body,cls,sub) VALUES('" + this.title.getText().toString() + "','" + this.body.getText().toString() + "','" + this.spinner.getSelectedItem().toString() + "','" + ((EditText) findViewById(C0319R.id.subjectNote)).getText().toString().toUpperCase() + "')")) {
            Toast.makeText(getBaseContext(), "Note Saved", 1).show();
            finish();
        }
    }
}
