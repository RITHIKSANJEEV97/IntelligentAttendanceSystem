package creations.raghul.smartattendance;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;

public class attendanceActivity extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!attendanceActivity.class.desiredAssertionStatus());
    public static String period;
    public static String time;
    listAdapter adapter;
    ArrayAdapter<String> adapterSpinner;
    ArrayAdapter<String> adapterSpinner1;
    ArrayAdapter<String> adapterSpinner2;
    Spinner attspinner;
    Spinner attspinner1;
    Spinner attspinner2;
    ArrayList<String> contact;
    ListView listView;
    ArrayList<String> names;
    ArrayList<String> registers;
    Activity thisActivity = this;

    class C03481 implements OnClickListener {
        C03481() {
        }

        public void onClick(View view) {
            attendanceActivity.this.adapter = new listAdapter(attendanceActivity.this.thisActivity, attendanceActivity.this.names, attendanceActivity.this.registers, attendanceActivity.this.contact, attendanceActivity.this.getApplication());
            attendanceActivity.this.adapter.selectedAll();
            attendanceActivity.this.listView.setAdapter(attendanceActivity.this.adapter);
        }
    }

    class C03492 implements OnClickListener {
        C03492() {
        }

        public void onClick(View view) {
            attendanceActivity.this.adapter = new listAdapter(attendanceActivity.this.thisActivity, attendanceActivity.this.names, attendanceActivity.this.registers, attendanceActivity.this.contact, attendanceActivity.this.getApplication());
            attendanceActivity.this.adapter.deselectedAll();
            attendanceActivity.this.listView.setAdapter(attendanceActivity.this.adapter);
        }
    }

    class C03503 implements OnClickListener {
        C03503() {
        }

        public void onClick(View v) {
            attendanceActivity.this.loadListView(v);
        }
    }

    class C03514 implements OnClickListener {
        C03514() {
        }

        public void onClick(View v) {
            Toast.makeText(attendanceActivity.this.getBaseContext(), "Saving", 1).show();
            attendanceActivity.this.adapter.saveAll();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_attendance);
        time = getIntent().getStringExtra("DATE");
        period = getIntent().getStringExtra("PERIOD");
        Log.d("Attendance", time + " -- " + period);
        this.listView = (ListView) findViewById(C0319R.id.attendanceListViwe);
        this.names = new ArrayList();
        this.registers = new ArrayList();
        this.contact = new ArrayList();
        Button abs = (Button) findViewById(C0319R.id.abs);
        ((Button) findViewById(C0319R.id.pre)).setOnClickListener(new C03481());
        abs.setOnClickListener(new C03492());
        Button btn = (Button) findViewById(C0319R.id.loadButton);
        if ($assertionsDisabled || btn != null) {
            btn.setOnClickListener(new C03503());
            Button btnx = (Button) findViewById(C0319R.id.buttonSaveAttendance);
            if ($assertionsDisabled || btnx != null) {
                btnx.setOnClickListener(new C03514());
                this.attspinner = (Spinner) findViewById(C0319R.id.attspinner);
                this.attspinner1 = (Spinner) findViewById(C0319R.id.attspinner1);
                this.attspinner2 = (Spinner) findViewById(C0319R.id.attspinner2);
                this.adapterSpinner = new ArrayAdapter(this, 17367049, AppBase.divisions);
                this.adapterSpinner1 = new ArrayAdapter(this, 17367049, AppBase.groups);
                this.adapterSpinner2 = new ArrayAdapter(this, 17367049, AppBase.Sections);
                if (!$assertionsDisabled && this.attspinner == null) {
                    throw new AssertionError();
                } else if (!$assertionsDisabled && this.attspinner1 == null) {
                    throw new AssertionError();
                } else if ($assertionsDisabled || this.attspinner2 != null) {
                    this.attspinner.setAdapter(this.adapterSpinner);
                    this.attspinner1.setAdapter(this.adapterSpinner1);
                    this.attspinner2.setAdapter(this.adapterSpinner2);
                    return;
                } else {
                    throw new AssertionError();
                }
            }
            throw new AssertionError();
        }
        throw new AssertionError();
    }

    public void loadListView(View view) {
        this.names.clear();
        this.registers.clear();
        this.contact.clear();
        Cursor cursor = AppBase.handler.execQuery("SELECT * FROM STUDENT WHERE cl = '" + this.attspinner.getSelectedItem().toString() + " " + this.attspinner1.getSelectedItem().toString() + " " + this.attspinner2.getSelectedItem().toString() + "' ORDER BY ROLL");
        if (!(cursor == null || cursor.getCount() == 0)) {
            int ctr = 0;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                this.names.add(cursor.getString(0) + " (" + cursor.getInt(4) + ')');
                this.registers.add(cursor.getString(2));
                this.contact.add(cursor.getString(3));
                cursor.moveToNext();
                ctr++;
            }
            if (ctr == 0) {
                Toast.makeText(getBaseContext(), "No Students Found", 1).show();
            }
            Log.d("Attendance", "Got " + ctr + " students");
        }
        this.adapter = new listAdapter(this.thisActivity, this.names, this.registers, this.contact, this);
        this.listView.setAdapter(this.adapter);
    }
}
