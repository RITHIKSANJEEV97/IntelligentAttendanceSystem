package creations.raghul.smartattendance;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class MessageAdapter extends ArrayAdapter<ChatMessage> {
    private Activity activity;
    private List<ChatMessage> messages;

    private class ViewHolder {
        private TextView msg;

        public ViewHolder(View v) {
            this.msg = (TextView) v.findViewById(C0319R.id.txt_msg);
        }
    }

    public MessageAdapter(Activity context, int resource, List<ChatMessage> objects) {
        super(context, resource, objects);
        this.activity = context;
        this.messages = objects;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        int layoutResource;
        ViewHolder holder;
        LayoutInflater inflater = (LayoutInflater) this.activity.getSystemService("layout_inflater");
        ChatMessage chatMessage = (ChatMessage) getItem(position);
        int viewType = getItemViewType(position);
        if (chatMessage.isMine()) {
            layoutResource = C0319R.layout.item_chat_left;
        } else {
            layoutResource = C0319R.layout.item_chat_right;
        }
        if (convertView != null) {
            holder = (ViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(layoutResource, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }
        holder.msg.setText(chatMessage.getContent());
        return convertView;
    }

    public int getViewTypeCount() {
        return 2;
    }

    public int getItemViewType(int position) {
        return position % 2;
    }
}
