package creations.raghul.smartattendance;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class excelexample extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_excelexample);
        setTitle("Follow this in Excel");
    }
}
