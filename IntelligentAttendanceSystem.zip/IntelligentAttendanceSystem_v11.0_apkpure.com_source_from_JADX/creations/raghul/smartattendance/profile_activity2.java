package creations.raghul.smartattendance;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class profile_activity2 extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!profile_activity2.class.desiredAssertionStatus());
    Activity activity = this;
    profile_adapter adapter;
    ArrayList<Boolean> atts;
    ArrayList<String> dates;
    ArrayList<String> datesALONE;
    databaseHandler handler = AppBase.handler;
    ArrayList<Integer> hourALONE;
    ListView listView;
    Activity profileActivity = this;
    private View f28v;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.stu_profile2);
        this.dates = new ArrayList();
        this.datesALONE = new ArrayList();
        this.hourALONE = new ArrayList();
        this.atts = new ArrayList();
        this.listView = (ListView) findViewById(C0319R.id.attendProfileView_list2);
        TextView textView = (TextView) findViewById(C0319R.id.profileContentView2);
        if ($assertionsDisabled || textView != null) {
            find(this.f28v);
            return;
        }
        throw new AssertionError();
    }

    public void find(View view) {
        this.dates.clear();
        this.atts.clear();
        TextView textView = (TextView) findViewById(C0319R.id.profileContentView2);
        String reg = getIntent().getExtras().getString("reg");
        Toast.makeText(getApplicationContext(), reg, 1).show();
        String qc = "SELECT * FROM ATTENDANCETEST WHERE register = '" + reg.toUpperCase() + "';";
        String qd = "SELECT * FROM ATTENDANCETEST WHERE register = '" + reg.toUpperCase() + "' AND isPresent = 1";
        float att = 0.0f;
        Cursor cur = this.handler.execQuery(qc);
        Cursor cur1 = this.handler.execQuery(qd);
        if (cur == null) {
            Log.d("profile", "cur null");
        }
        if (cur1 == null) {
            Log.d("profile", "cur1 null");
        }
        if (!(cur == null || cur1 == null)) {
            cur.moveToFirst();
            cur1.moveToFirst();
            try {
                att = (((float) cur1.getCount()) / ((float) cur.getCount())) * 100.0f;
                if (att <= 0.0f) {
                    att = 0.0f;
                }
                Log.d("profile_activity", "Total = " + cur.getCount() + " avail = " + cur1.getCount() + " per " + att);
            } catch (Exception e) {
                att = -1.0f;
            }
        }
        textView.setText("Your Attendance Percentasge is : " + att + "\n\nFor Period/Day wise Details\n\nLook Below\n");
        Cursor cursorx = this.handler.execQuery("SELECT * FROM ATTENDANCETEST WHERE register = '" + getIntent().getExtras().getString("reg").toUpperCase() + "'");
        if (cursorx == null || cursorx.getCount() == 0) {
            Toast.makeText(getBaseContext(), "No Attendance Info Available", 1).show();
            return;
        }
        cursorx.moveToFirst();
        while (!cursorx.isAfterLast()) {
            this.datesALONE.add(cursorx.getString(0));
            this.hourALONE.add(Integer.valueOf(cursorx.getInt(1)));
            this.dates.add(cursorx.getString(0) + ":" + cursorx.getInt(1) + "th Hour");
            if (cursorx.getInt(3) == 1) {
                this.atts.add(Boolean.valueOf(true));
            } else {
                Log.d("profile", cursorx.getString(0) + " -> " + cursorx.getInt(3));
                this.atts.add(Boolean.valueOf(false));
            }
            cursorx.moveToNext();
        }
        this.adapter = new profile_adapter(this.dates, this.atts, this.profileActivity, this.datesALONE, this.hourALONE, getIntent().getExtras().getString("reg").toUpperCase());
        this.listView.setAdapter(this.adapter);
    }
}
