package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.support.v7.app.ActionBar;
import android.view.MenuItem;
import android.widget.Toast;

public class SettingsActivity extends AppCompatPreferenceActivity {
    Activity base = this;

    class C03221 implements OnPreferenceClickListener {

        class C03201 implements OnClickListener {
            C03201() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DROP TABLE SCHEDULE")) {
                    Toast.makeText(SettingsActivity.this.getBaseContext(), "Done", 1).show();
                    AppBase.handler.createTable();
                    dialog.dismiss();
                }
            }
        }

        class C03212 implements OnClickListener {
            C03212() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03221() {
        }

        public boolean onPreferenceClick(Preference preference) {
            Builder alert = new Builder(SettingsActivity.this.base);
            alert.setTitle("Are you sure ?");
            alert.setMessage("This will wipe your entire scheduling data");
            alert.setPositiveButton("YES", new C03201());
            alert.setNegativeButton("NO", new C03212());
            alert.show();
            return true;
        }
    }

    class C03252 implements OnPreferenceClickListener {

        class C03231 implements OnClickListener {
            C03231() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DROP TABLE ATTENDANCE")) {
                    Toast.makeText(SettingsActivity.this.getBaseContext(), "Done", 1).show();
                    AppBase.handler.createTable();
                    dialog.dismiss();
                }
            }
        }

        class C03242 implements OnClickListener {
            C03242() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03252() {
        }

        public boolean onPreferenceClick(Preference preference) {
            Builder alert = new Builder(SettingsActivity.this.base);
            alert.setTitle("Are you sure ?");
            alert.setMessage("This will wipe your entire attendance data");
            alert.setPositiveButton("YES", new C03231());
            alert.setNegativeButton("NO", new C03242());
            alert.show();
            return true;
        }
    }

    class C03283 implements OnPreferenceClickListener {

        class C03261 implements OnClickListener {
            C03261() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DROP TABLE NOTES")) {
                    Toast.makeText(SettingsActivity.this.getBaseContext(), "Done", 1).show();
                    AppBase.handler.createTable();
                    dialog.dismiss();
                }
            }
        }

        class C03272 implements OnClickListener {
            C03272() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03283() {
        }

        public boolean onPreferenceClick(Preference preference) {
            Builder alert = new Builder(SettingsActivity.this.base);
            alert.setTitle("Are you sure ?");
            alert.setMessage("This will wipe your entire Notes data");
            alert.setPositiveButton("YES", new C03261());
            alert.setNegativeButton("NO", new C03272());
            alert.show();
            return true;
        }
    }

    class C03314 implements OnPreferenceClickListener {

        class C03291 implements OnClickListener {
            C03291() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DROP TABLE STUDENT")) {
                    Toast.makeText(SettingsActivity.this.getBaseContext(), "Done", 1).show();
                    AppBase.handler.createTable();
                    dialog.dismiss();
                }
            }
        }

        class C03302 implements OnClickListener {
            C03302() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C03314() {
        }

        public boolean onPreferenceClick(Preference preference) {
            Builder alert = new Builder(SettingsActivity.this.base);
            alert.setTitle("Are you sure ?");
            alert.setMessage("This will wipe your entire Student data");
            alert.setPositiveButton("YES", new C03291());
            alert.setNegativeButton("NO", new C03302());
            alert.show();
            return true;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
        addPreferencesFromResource(C0319R.xml.pref_general);
        findPreference("clear_schedule").setOnPreferenceClickListener(new C03221());
        findPreference("clear_attendance").setOnPreferenceClickListener(new C03252());
        findPreference("clear_notes").setOnPreferenceClickListener(new C03283());
        findPreference("clear_student").setOnPreferenceClickListener(new C03314());
    }

    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
