package creations.raghul.smartattendance;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

public class databaseHandler {
    Activity activity;
    SQLiteDatabase database;

    public databaseHandler(Activity activity) {
        this.activity = activity;
        this.database = activity.openOrCreateDatabase("ASSIST", 0, null);
        createTable();
    }

    public void createTable() {
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS STUDENT(name varchar(1000),cl varchar(100), regno varchar(100) primary key, contact varchar(100),roll integer);");
        } catch (Exception e) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS ATTENDANCE(datex date,hour int, register varchar(100) ,isPresent boolean);");
        } catch (Exception e2) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS ATTENDANCETEST(datex date,hour int, register varchar(100) ,isPresent boolean);");
        } catch (Exception e3) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS NOTES(title varchar(100) not null,body varchar(10000), cls varchar(1000), sub varchar(1000) ,datex TIMESTAMP default CURRENT_TIMESTAMP);");
        } catch (Exception e4) {
            Toast.makeText(this.activity, "Error Occured for create table" + e4.toString(), 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS SCHEDULE(cl varchar(100),subject varchar(1000),timex time, day_week varchar(100));");
        } catch (Exception e5) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS ACC(reg varchar(20),pword varchar(20));");
        } catch (Exception e6) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS SENDMSG(text int);");
        } catch (Exception e7) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
        try {
            this.database.execSQL("CREATE TABLE IF NOT EXISTS LEVIT(text int);");
        } catch (Exception e8) {
            Toast.makeText(this.activity, "Error Occured for create table", 1).show();
        }
    }

    public boolean execAction(String qu) {
        Log.i("databaseHandler", qu);
        try {
            this.database.execSQL(qu);
            return true;
        } catch (Exception e) {
            Log.e("databaseHandler", qu);
            return false;
        }
    }

    Cursor execQuery(String qu) {
        Cursor cursor = null;
        try {
            cursor = this.database.rawQuery(qu, null);
        } catch (Exception e) {
            Log.e("databaseHandler", qu);
        }
        return cursor;
    }
}
