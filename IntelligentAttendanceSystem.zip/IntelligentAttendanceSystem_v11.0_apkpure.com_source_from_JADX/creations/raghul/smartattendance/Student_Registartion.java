package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class Student_Registartion extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!Student_Registartion.class.desiredAssertionStatus());
    Activity activity = this;
    Context con = this;
    Spinner spinner;
    Spinner spinner1;
    Spinner spinner2;

    class C03321 implements OnClickListener {
        C03321() {
        }

        public void onClick(View v) {
            Student_Registartion.this.saveToDatabase(v);
        }
    }

    class C03332 implements OnClickListener {
        C03332() {
        }

        public void onClick(View view) {
            Student_Registartion.this.readandsave(view);
        }
    }

    static class C03343 implements DialogInterface.OnClickListener {
        C03343() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_student__registartion);
        this.spinner = (Spinner) findViewById(C0319R.id.spinner);
        this.spinner1 = (Spinner) findViewById(C0319R.id.spinner1);
        this.spinner2 = (Spinner) findViewById(C0319R.id.spinner2);
        ArrayAdapter<String> adapter = new ArrayAdapter(this, 17367049, AppBase.divisions);
        ArrayAdapter<String> adapter1 = new ArrayAdapter(this, 17367049, AppBase.groups);
        ArrayAdapter<String> adapter2 = new ArrayAdapter(this, 17367049, AppBase.Sections);
        this.spinner.setAdapter(adapter);
        this.spinner1.setAdapter(adapter1);
        this.spinner2.setAdapter(adapter2);
        Button btn = (Button) findViewById(C0319R.id.buttonSAVE);
        if ($assertionsDisabled || btn != null) {
            btn.setOnClickListener(new C03321());
            ((Button) findViewById(C0319R.id.buttonexcel)).setOnClickListener(new C03332());
            return;
        }
        throw new AssertionError();
    }

    public void openexample(View view) {
        startActivity(new Intent(this, excelexample.class));
    }

    public void readandsave(View view) {
        readExcelFile(this, "stu.xls");
    }

    private static void readExcelFile(Context context, String filename) {
        try {
            Iterator rowIter = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(new File(Environment.getExternalStorageDirectory(), filename)))).getSheetAt(0).rowIterator();
            int i = 0;
            while (rowIter.hasNext()) {
                String roll;
                Iterator cellIter = ((HSSFRow) rowIter.next()).cellIterator();
                String name = ((HSSFCell) cellIter.next()).toString();
                String reg = ((HSSFCell) cellIter.next()).toString();
                String clas = ((HSSFCell) cellIter.next()).toString();
                String phno = ((HSSFCell) cellIter.next()).toString().substring(1);
                if (i == 0) {
                    roll = "00";
                } else {
                    roll = reg.substring(reg.length() - 3);
                }
                String qu = "INSERT INTO STUDENT VALUES('" + name + "','" + clas + "','" + reg.toUpperCase() + "','" + phno + "'," + Integer.parseInt(roll) + ");";
                Log.d("Student Reg", qu);
                if (i != 0) {
                    try {
                        AppBase.handler.execAction(qu);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                i++;
            }
            Toast.makeText(context, "Successfully Imported", 1).show();
        } catch (Exception e2) {
            Toast.makeText(context, "File stu.xls not found in Phone Storage", 0).show();
            AlertDialog alertDialog = new Builder(context).create();
            alertDialog.setTitle("Warning");
            alertDialog.setMessage("Excel file name must be stu.xls and it should be located in phone memory. It should not be located inside any folder. Just directly in phone memory named as stu.xls");
            alertDialog.setButton(-3, "OK", new C03343());
            alertDialog.show();
        }
    }

    public void proImportCSV(File form) throws IOException {
    }

    public void saveToDatabase(View view) {
        EditText name = (EditText) findViewById(C0319R.id.edit_name);
        EditText roll = (EditText) findViewById(C0319R.id.roll);
        EditText register = (EditText) findViewById(C0319R.id.register);
        EditText contact = (EditText) findViewById(C0319R.id.contact);
        String classSelected = this.spinner.getSelectedItem().toString() + " " + this.spinner1.getSelectedItem() + " " + this.spinner2.getSelectedItem();
        if (name.getText().length() < 2 || roll.getText().length() == 0 || register.getText().length() < 2 || contact.getText().length() < 2 || classSelected.length() < 2) {
            Builder alert = new Builder(this.activity);
            alert.setTitle("Invalid");
            alert.setMessage("Insufficient Data");
            alert.setPositiveButton("OK", null);
            alert.show();
            return;
        }
        String qu = "INSERT INTO STUDENT VALUES('" + name.getText().toString() + "','" + classSelected + "','" + register.getText().toString().toUpperCase() + "','" + contact.getText().toString() + "'," + Integer.parseInt(roll.getText().toString()) + ");";
        Log.d("Student Reg", qu);
        AppBase.handler.execAction(qu);
        qu = "SELECT * FROM STUDENT WHERE regno = '" + register.getText().toString() + "';";
        Log.d("Student Reg", qu);
        if (AppBase.handler.execQuery(qu) != null) {
            Toast.makeText(getBaseContext(), "Done", 1).show();
            finish();
        }
    }
}
