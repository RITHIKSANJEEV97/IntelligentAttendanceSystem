package creations.raghul.smartattendance;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class profile_activity extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!profile_activity.class.desiredAssertionStatus());
    Activity activity = this;
    profile_adapter adapter;
    ArrayList<Boolean> atts;
    ArrayList<String> dates;
    ArrayList<String> datesALONE;
    databaseHandler handler = AppBase.handler;
    ArrayList<Integer> hourALONE;
    ListView listView;
    Activity profileActivity = this;
    private View f29v;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startActivity(new Intent(this.profileActivity, Student_Registartion.class));
        finish();
    }

    public void find(View view) {
        this.dates.clear();
        this.atts.clear();
        EditText editText = (EditText) findViewById(C0319R.id.editText);
        TextView textView = (TextView) findViewById(C0319R.id.profileContentView);
        String reg = editText.getText().toString();
        String qu = "SELECT * FROM STUDENT WHERE regno = '" + reg.toUpperCase() + "'";
        String qc = "SELECT * FROM ATTENDANCETEST WHERE register = '" + reg.toUpperCase() + "';";
        String qd = "SELECT * FROM ATTENDANCETEST WHERE register = '" + reg.toUpperCase() + "' AND isPresent = 1";
        Cursor cursor = this.handler.execQuery(qu);
        float att = 0.0f;
        Cursor cur = this.handler.execQuery(qc);
        Cursor cur1 = this.handler.execQuery(qd);
        if (cur == null) {
            Log.d("profile", "cur null");
        }
        if (cur1 == null) {
            Log.d("profile", "cur1 null");
        }
        if (!(cur == null || cur1 == null)) {
            cur.moveToFirst();
            cur1.moveToFirst();
            try {
                att = (((float) cur1.getCount()) / ((float) cur.getCount())) * 100.0f;
                if (att <= 0.0f) {
                    att = 0.0f;
                }
                Log.d("profile_activity", "Total = " + cur.getCount() + " avail = " + cur1.getCount() + " per " + att);
            } catch (Exception e) {
                att = -1.0f;
            }
        }
        if (cursor != null && cursor.getCount() != 0) {
            String attendance = "";
            if (att < 0.0f) {
                attendance = "Attendance Not Available";
            } else {
                attendance = " Attendance " + att + " %";
            }
            cursor.moveToFirst();
            TextView textView2 = textView;
            textView2.setText(((((("" + " " + cursor.getString(0) + "\n") + " " + cursor.getString(1) + "\n") + " " + cursor.getString(2) + "\n") + " " + cursor.getString(3) + "\n") + " " + cursor.getInt(4) + "\n") + " " + attendance + "\n");
            Cursor cursorx = this.handler.execQuery("SELECT * FROM ATTENDANCETEST WHERE register = '" + editText.getText().toString().toUpperCase() + "'");
            if (cursorx == null || cursorx.getCount() == 0) {
                Toast.makeText(getBaseContext(), "No Attendance Info Available", 1).show();
                return;
            }
            cursorx.moveToFirst();
            while (!cursorx.isAfterLast()) {
                this.datesALONE.add(cursorx.getString(0));
                this.hourALONE.add(Integer.valueOf(cursorx.getInt(1)));
                this.dates.add(cursorx.getString(0) + ":" + cursorx.getInt(1) + "th Hour");
                if (cursorx.getInt(3) == 1) {
                    this.atts.add(Boolean.valueOf(true));
                } else {
                    Log.d("profile", cursorx.getString(0) + " -> " + cursorx.getInt(3));
                    this.atts.add(Boolean.valueOf(false));
                }
                cursorx.moveToNext();
            }
            this.adapter = new profile_adapter(this.dates, this.atts, this.profileActivity, this.datesALONE, this.hourALONE, editText.getText().toString().toUpperCase());
            this.listView.setAdapter(this.adapter);
        } else if ($assertionsDisabled || textView != null) {
            textView.setText("No Data Available");
        } else {
            throw new AssertionError();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(C0319R.menu.profile_menu, menu);
        return true;
    }

    public void editStudent(MenuItem item) {
        startActivity(new Intent(this, Edit_Student.class));
    }
}
