package creations.raghul.smartattendance;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import java.util.ArrayList;

public class profile_adapter extends BaseAdapter {
    Activity activity;
    ArrayList<String> dates;
    ArrayList<String> datesALONE;
    ArrayList<Integer> hourALONE;
    ArrayList<Boolean> present;
    String uname;

    public profile_adapter(ArrayList<String> dates, ArrayList<Boolean> present, Activity activity, ArrayList<String> datesALONE, ArrayList<Integer> hourALONE, String re) {
        this.dates = dates;
        this.present = present;
        this.activity = activity;
        this.datesALONE = datesALONE;
        this.hourALONE = hourALONE;
        this.uname = re;
    }

    public int getCount() {
        return this.dates.size();
    }

    public Object getItem(int position) {
        return this.dates.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View v, ViewGroup parent) {
        if (v == null) {
            v = LayoutInflater.from(this.activity).inflate(C0319R.layout.list_ele, null);
        }
        int pos = position;
        ((TextView) v.findViewById(C0319R.id.attendanceName)).setText((CharSequence) this.dates.get(position));
        CheckBox checkBox = (CheckBox) v.findViewById(C0319R.id.attMarker);
        checkBox.setClickable(false);
        Log.d("Profile", this.present.get(position) + "");
        checkBox.setChecked(((Boolean) this.present.get(position)).booleanValue());
        return v;
    }
}
