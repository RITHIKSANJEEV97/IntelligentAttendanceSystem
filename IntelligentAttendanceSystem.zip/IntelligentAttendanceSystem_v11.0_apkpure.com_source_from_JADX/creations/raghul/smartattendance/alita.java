package creations.raghul.smartattendance;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.speech.SpeechRecognizer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;

public class alita extends AppCompatActivity {
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private ArrayAdapter<ChatMessage> adapter;
    JSONArray arr;
    private View btnSend;
    private View btnSpeak;
    private List<ChatMessage> chatMessages;
    String[] datex = new String[100];
    private EditText editText;
    String[] hour = new String[100];
    boolean isMine = false;
    String[] isp = new String[100];
    int kflag = 0;
    private ListView listView;
    String np;
    String op;
    String[] pass = new String[100];
    int passcheck = 0;
    String password = "";
    String pp;
    String qc11;
    String reg = "";
    String[] register = new String[100];
    private SpeechRecognizer sr;
    String temp;
    String temp1;
    String temp2;
    String text;
    String text2;
    String tp;
    private TextView txtSpeechInput;
    String[] use = new String[100];
    int f27x;

    class C03351 implements OnClickListener {
        C03351() {
        }

        public void onClick(View view) {
            Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
            intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
            intent.putExtra("android.speech.extra.LANGUAGE", Locale.getDefault());
            try {
                alita.this.startActivityForResult(intent, 100);
            } catch (ActivityNotFoundException e) {
            }
        }
    }

    class C03362 implements OnClickListener {
        C03362() {
        }

        public void onClick(View v) {
            if (alita.this.editText.getText().toString().trim().equals("")) {
                Toast.makeText(alita.this, "Say Something. I love to assist you !", 0).show();
                return;
            }
            String message = alita.this.editText.getText().toString();
            alita.this.chatMessages.add(new ChatMessage(message, alita.this.isMine));
            alita.this.adapter.notifyDataSetChanged();
            alita.this.editText.setText("");
            if (alita.this.isMine) {
                alita.this.isMine = false;
            } else {
                alita.this.isMine = true;
            }
            String text = alita.this.mainprocess(message.toLowerCase());
            alita.this.chatMessages.add(new ChatMessage(text.substring(0, 1).toUpperCase() + text.substring(1), alita.this.isMine));
            alita.this.adapter.notifyDataSetChanged();
            if (alita.this.isMine) {
                alita.this.isMine = false;
            } else {
                alita.this.isMine = true;
            }
        }
    }

    class C03373 implements DialogInterface.OnClickListener {
        C03373() {
        }

        public void onClick(DialogInterface dialog, int id) {
            dialog.cancel();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (Integer.parseInt(VERSION.SDK) <= 5 || keyCode != 4 || event.getRepeatCount() != 0) {
            return super.onKeyDown(keyCode, event);
        }
        Log.d("CDA", "onKeyDown Called");
        onBackPressed();
        return true;
    }

    public void onBackPressed() {
        String qq = "select * from acc;";
        try {
            this.kflag = 0;
            Cursor ccr = AppBase.handler.execQuery(qq);
            ccr.moveToFirst();
            if (ccr.isAfterLast() || ccr.getString(1).equals("")) {
                Toast.makeText(this, "Securit Warning ! You Can't back stack without staff login.", 0).show();
                Toast.makeText(this, "Press home button to exit this App", 1).show();
                return;
            }
            finish();
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), 1).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 100:
                if (resultCode == -1 && data != null) {
                    this.editText.setText((CharSequence) data.getStringArrayListExtra("android.speech.extra.RESULTS").get(0));
                    return;
                }
                return;
            default:
                return;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_main);
        getWindow().getDecorView().setSystemUiVisibility(4);
        this.btnSpeak = (ImageButton) findViewById(C0319R.id.btnSpeak);
        AppBase.handler.execAction("delete from ATTENDANCETEST;");
        setTitle("Alita");
        this.f27x = 0;
        this.chatMessages = new ArrayList();
        this.listView = (ListView) findViewById(C0319R.id.list_msg);
        this.btnSend = findViewById(C0319R.id.btnSend);
        this.editText = (EditText) findViewById(C0319R.id.txtSpeechInput);
        this.adapter = new MessageAdapter(this, C0319R.layout.item_chat_left, this.chatMessages);
        this.listView.setAdapter(this.adapter);
        this.btnSpeak.setOnClickListener(new C03351());
        this.btnSend.setOnClickListener(new C03362());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    java.lang.String mainprocess(java.lang.String r65) {
        /*
        r64 = this;
        r37 = r65;
        r0 = r37;
        r1 = r64;
        r1.text = r0;
        r0 = r37;
        r1 = r64;
        r1.text2 = r0;
        r5 = "PREFERENCE";
        r6 = 0;
        r0 = r64;
        r5 = r0.getSharedPreferences(r5, r6);
        r6 = "isFirstRun";
        r7 = 1;
        r5 = r5.getBoolean(r6, r7);
        r34 = java.lang.Boolean.valueOf(r5);
        r10 = "MyPrefsFile";
        r5 = "MyPrefsFile";
        r6 = 0;
        r0 = r64;
        r58 = r0.getSharedPreferences(r5, r6);
        r5 = "my_first_time";
        r6 = 1;
        r0 = r58;
        r5 = r0.getBoolean(r5, r6);
        if (r5 == 0) goto L_0x0055;
    L_0x0038:
        r5 = "Comments";
        r6 = "First time";
        android.util.Log.d(r5, r6);
        r64.firstuse();
        r5 = r58.edit();
        r6 = "my_first_time";
        r7 = 0;
        r5 = r5.putBoolean(r6, r7);
        r5.commit();
        r0 = r64;
        r5 = r0.text;
    L_0x0054:
        return r5;
    L_0x0055:
        r5 = "log";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x0069;
    L_0x005f:
        r5 = "out";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0091;
    L_0x0069:
        r5 = "sign";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x007d;
    L_0x0073:
        r5 = "out";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0091;
    L_0x007d:
        r5 = "logout";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0091;
    L_0x0087:
        r5 = "signout";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x00a5;
    L_0x0091:
        r49 = "delete from acc;";
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r49;
        r5.execAction(r0);
        r5 = "Logout Successful";
        r0 = r64;
        r0.text = r5;
    L_0x00a0:
        r0 = r64;
        r5 = r0.text;
        goto L_0x0054;
    L_0x00a5:
        r5 = "change";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x017d;
    L_0x00af:
        r5 = "password";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x017d;
    L_0x00b9:
        r49 = "select * from acc;";
        r5 = creations.raghul.smartattendance.AppBase.handler;	 Catch:{ Exception -> 0x0168 }
        r0 = r49;
        r18 = r5.execQuery(r0);	 Catch:{ Exception -> 0x0168 }
        r18.moveToFirst();	 Catch:{ Exception -> 0x0168 }
        r5 = 0;
        r0 = r18;
        r5 = r0.getString(r5);	 Catch:{ Exception -> 0x0168 }
        r0 = r64;
        r0.text2 = r5;	 Catch:{ Exception -> 0x0168 }
        r5 = 1;
        r0 = r18;
        r5 = r0.getString(r5);	 Catch:{ Exception -> 0x0168 }
        r0 = r64;
        r0.tp = r5;	 Catch:{ Exception -> 0x0168 }
        r5 = r18.isAfterLast();	 Catch:{ Exception -> 0x0168 }
        if (r5 != 0) goto L_0x00ee;
    L_0x00e2:
        r0 = r64;
        r5 = r0.tp;	 Catch:{ Exception -> 0x0168 }
        r6 = "";
        r5 = r5.equals(r6);	 Catch:{ Exception -> 0x0168 }
        if (r5 == 0) goto L_0x0101;
    L_0x00ee:
        r5 = "You Need to login in order to change the password";
        r6 = 0;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);	 Catch:{ Exception -> 0x0168 }
        r5.show();	 Catch:{ Exception -> 0x0168 }
    L_0x00fa:
        r5 = "Yup";
        r0 = r64;
        r0.text = r5;
        goto L_0x00a0;
    L_0x0101:
        r36 = android.view.LayoutInflater.from(r64);	 Catch:{ Exception -> 0x0168 }
        r5 = 2131361868; // 0x7f0a004c float:1.83435E38 double:1.053032678E-314;
        r6 = 0;
        r0 = r36;
        r44 = r0.inflate(r5, r6);	 Catch:{ Exception -> 0x0168 }
        r11 = new android.app.AlertDialog$Builder;	 Catch:{ Exception -> 0x0168 }
        r0 = r64;
        r11.<init>(r0);	 Catch:{ Exception -> 0x0168 }
        r0 = r44;
        r11.setView(r0);	 Catch:{ Exception -> 0x0168 }
        r5 = 2131230955; // 0x7f0800eb float:1.8077977E38 double:1.052967998E-314;
        r0 = r44;
        r62 = r0.findViewById(r5);	 Catch:{ Exception -> 0x0168 }
        r62 = (android.widget.EditText) r62;	 Catch:{ Exception -> 0x0168 }
        r5 = 2131230812; // 0x7f08005c float:1.8077687E38 double:1.0529679276E-314;
        r0 = r44;
        r60 = r0.findViewById(r5);	 Catch:{ Exception -> 0x0168 }
        r60 = (android.widget.EditText) r60;	 Catch:{ Exception -> 0x0168 }
        r5 = 2131230813; // 0x7f08005d float:1.807769E38 double:1.052967928E-314;
        r0 = r44;
        r61 = r0.findViewById(r5);	 Catch:{ Exception -> 0x0168 }
        r61 = (android.widget.EditText) r61;	 Catch:{ Exception -> 0x0168 }
        r5 = 0;
        r5 = r11.setCancelable(r5);	 Catch:{ Exception -> 0x0168 }
        r6 = "OK";
        r7 = new creations.raghul.smartattendance.alita$4;	 Catch:{ Exception -> 0x0168 }
        r0 = r64;
        r1 = r62;
        r2 = r60;
        r3 = r61;
        r7.<init>(r1, r2, r3);	 Catch:{ Exception -> 0x0168 }
        r5 = r5.setPositiveButton(r6, r7);	 Catch:{ Exception -> 0x0168 }
        r6 = "Cancel";
        r7 = new creations.raghul.smartattendance.alita$3;	 Catch:{ Exception -> 0x0168 }
        r0 = r64;
        r7.<init>();	 Catch:{ Exception -> 0x0168 }
        r5.setNegativeButton(r6, r7);	 Catch:{ Exception -> 0x0168 }
        r12 = r11.create();	 Catch:{ Exception -> 0x0168 }
        r12.show();	 Catch:{ Exception -> 0x0168 }
        goto L_0x00fa;
    L_0x0168:
        r31 = move-exception;
        r5 = "Please Log in to Proceed";
        r0 = r64;
        r0.text = r5;
        r5 = "Software Security Blocked It";
        r6 = 1;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);
        r5.show();
        goto L_0x00fa;
    L_0x017d:
        r5 = "log";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x0187:
        r5 = "sign";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x0191:
        r5 = "signin";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x019b:
        r5 = "login";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x01a5:
        r5 = "register";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x01b9;
    L_0x01af:
        r5 = "i";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x01b9:
        r5 = "register";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x01cd;
    L_0x01c3:
        r5 = "me";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x01e1;
    L_0x01cd:
        r5 = "register";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x022d;
    L_0x01d7:
        r5 = "myself";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x022d;
    L_0x01e1:
        r5 = "Sure";
        r0 = r64;
        r0.text = r5;
        r5 = " ";
        r0 = r37;
        r13 = r0.split(r5);
        r43 = new android.app.ProgressDialog;
        r0 = r43;
        r1 = r64;
        r0.<init>(r1);
        r5 = "Downloading from Server";
        r0 = r43;
        r0.setMessage(r5);
        r43.show();
        r4 = new creations.raghul.smartattendance.alita$7;
        r6 = 1;
        r7 = "http://sraghul.com/wreadcloudat.php";
        r8 = new creations.raghul.smartattendance.alita$5;
        r0 = r64;
        r1 = r43;
        r8.<init>(r1, r13);
        r9 = new creations.raghul.smartattendance.alita$6;
        r0 = r64;
        r1 = r43;
        r9.<init>(r1);
        r5 = r64;
        r4.<init>(r6, r7, r8, r9);
        r5 = r64.getApplicationContext();
        r57 = com.android.volley.toolbox.Volley.newRequestQueue(r5);
        r0 = r57;
        r0.add(r4);
        goto L_0x00a0;
    L_0x022d:
        r5 = "mark";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0255;
    L_0x0237:
        r5 = "od";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0255;
    L_0x0241:
        r5 = "onduty";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0255;
    L_0x024b:
        r5 = "duty";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x02aa;
    L_0x0255:
        r49 = "select * from acc;";
        r5 = creations.raghul.smartattendance.AppBase.handler;	 Catch:{ Exception -> 0x028b }
        r0 = r49;
        r18 = r5.execQuery(r0);	 Catch:{ Exception -> 0x028b }
        r18.moveToFirst();	 Catch:{ Exception -> 0x028b }
        r5 = r18.isAfterLast();	 Catch:{ Exception -> 0x028b }
        if (r5 != 0) goto L_0x0277;
    L_0x0268:
        r5 = 1;
        r0 = r18;
        r5 = r0.getString(r5);	 Catch:{ Exception -> 0x028b }
        r6 = "";
        r5 = r5.equals(r6);	 Catch:{ Exception -> 0x028b }
        if (r5 == 0) goto L_0x029c;
    L_0x0277:
        r5 = "Specific Advisor Login Required.";
        r6 = 0;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);	 Catch:{ Exception -> 0x028b }
        r5.show();	 Catch:{ Exception -> 0x028b }
        r5 = "I think you must login first";
        r0 = r64;
        r0.text = r5;	 Catch:{ Exception -> 0x028b }
        goto L_0x00a0;
    L_0x028b:
        r31 = move-exception;
        r5 = r31.toString();
        r6 = 1;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);
        r5.show();
        goto L_0x00a0;
    L_0x029c:
        r5 = "Just to Confirm, Please say Roll Number";
        r0 = r64;
        r0.text = r5;	 Catch:{ Exception -> 0x028b }
        r5 = 46;
        r0 = r64;
        r0.f27x = r5;	 Catch:{ Exception -> 0x028b }
        goto L_0x00a0;
    L_0x02aa:
        r0 = r64;
        r5 = r0.f27x;
        r6 = 46;
        if (r5 != r6) goto L_0x02c6;
    L_0x02b2:
        r5 = "Just to Confirm, Please say Date";
        r0 = r64;
        r0.text = r5;
        r0 = r37;
        r1 = r64;
        r1.temp = r0;
        r5 = 56;
        r0 = r64;
        r0.f27x = r5;
        goto L_0x00a0;
    L_0x02c6:
        r0 = r64;
        r5 = r0.f27x;
        r6 = 56;
        if (r5 != r6) goto L_0x02e2;
    L_0x02ce:
        r5 = "Just to Confirm, Please say Hour";
        r0 = r64;
        r0.text = r5;
        r0 = r37;
        r1 = r64;
        r1.temp1 = r0;
        r5 = 78;
        r0 = r64;
        r0.f27x = r5;
        goto L_0x00a0;
    L_0x02e2:
        r0 = r64;
        r5 = r0.f27x;
        r6 = 78;
        if (r5 != r6) goto L_0x0329;
    L_0x02ea:
        r43 = new android.app.ProgressDialog;
        r0 = r43;
        r1 = r64;
        r0.<init>(r1);
        r5 = "Updating on Server";
        r0 = r43;
        r0.setMessage(r5);
        r43.show();
        r4 = new creations.raghul.smartattendance.alita$10;
        r6 = 1;
        r7 = "http://sraghul.com/writecloudat.php";
        r8 = new creations.raghul.smartattendance.alita$8;
        r0 = r64;
        r1 = r43;
        r8.<init>(r1);
        r9 = new creations.raghul.smartattendance.alita$9;
        r0 = r64;
        r1 = r43;
        r9.<init>(r1);
        r5 = r64;
        r4.<init>(r6, r7, r8, r9);
        r57 = com.android.volley.toolbox.Volley.newRequestQueue(r64);
        r0 = r57;
        r0.add(r4);
        r5 = 1;
        r0 = r64;
        r0.f27x = r5;
        goto L_0x00a0;
    L_0x0329:
        r5 = "export";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0347;
    L_0x0333:
        r5 = "excel";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0347;
    L_0x033d:
        r5 = "exel";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x0396;
    L_0x0347:
        r49 = "select * from acc;";
        r5 = creations.raghul.smartattendance.AppBase.handler;	 Catch:{ Exception -> 0x0377 }
        r0 = r49;
        r18 = r5.execQuery(r0);	 Catch:{ Exception -> 0x0377 }
        r18.moveToFirst();	 Catch:{ Exception -> 0x0377 }
        r5 = r18.isAfterLast();	 Catch:{ Exception -> 0x0377 }
        if (r5 != 0) goto L_0x0369;
    L_0x035a:
        r5 = 1;
        r0 = r18;
        r5 = r0.getString(r5);	 Catch:{ Exception -> 0x0377 }
        r6 = "";
        r5 = r5.equals(r6);	 Catch:{ Exception -> 0x0377 }
        if (r5 == 0) goto L_0x0388;
    L_0x0369:
        r5 = "Specific Advisor Login Required.";
        r6 = 0;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);	 Catch:{ Exception -> 0x0377 }
        r5.show();	 Catch:{ Exception -> 0x0377 }
        goto L_0x00a0;
    L_0x0377:
        r31 = move-exception;
        r5 = r31.toString();
        r6 = 1;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);
        r5.show();
        goto L_0x00a0;
    L_0x0388:
        r5 = "Just to Confirm, Please say your class";
        r0 = r64;
        r0.text = r5;	 Catch:{ Exception -> 0x0377 }
        r5 = 99;
        r0 = r64;
        r0.f27x = r5;	 Catch:{ Exception -> 0x0377 }
        goto L_0x00a0;
    L_0x0396:
        r0 = r64;
        r5 = r0.f27x;
        r6 = 99;
        if (r5 != r6) goto L_0x08bb;
    L_0x039e:
        r40 = new java.util.ArrayList;
        r40.<init>();
        r52 = new java.util.ArrayList;
        r52.<init>();
        r20 = new java.util.ArrayList;
        r20.<init>();
        r19 = r37;
        r5 = 1;
        r0 = r64;
        r1 = r19;
        r5 = android.widget.Toast.makeText(r0, r1, r5);
        r5.show();
        r40.clear();
        r52.clear();
        r20.clear();
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM STUDENT WHERE cl = '";
        r5 = r5.append(r6);
        r6 = r19.toUpperCase();
        r5 = r5.append(r6);
        r6 = "' ORDER BY regno";
        r5 = r5.append(r6);
        r50 = r5.toString();
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r50;
        r26 = r5.execQuery(r0);
        if (r26 == 0) goto L_0x03f1;
    L_0x03eb:
        r5 = r26.getCount();
        if (r5 != 0) goto L_0x040a;
    L_0x03f1:
        r5 = "Got null";
        r6 = 1;
        r0 = r64;
        r5 = android.widget.Toast.makeText(r0, r5, r6);
        r5.show();
    L_0x03fd:
        r5 = 1;
        r0 = r64;
        r0.f27x = r5;
        r5 = "Exported";
        r0 = r64;
        r0.text = r5;
        goto L_0x00a0;
    L_0x040a:
        r22 = 0;
        r26.moveToFirst();
    L_0x040f:
        r5 = r26.isAfterLast();
        if (r5 != 0) goto L_0x0463;
    L_0x0415:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = 0;
        r0 = r26;
        r6 = r0.getString(r6);
        r5 = r5.append(r6);
        r6 = " (";
        r5 = r5.append(r6);
        r6 = 4;
        r0 = r26;
        r6 = r0.getInt(r6);
        r5 = r5.append(r6);
        r6 = 41;
        r5 = r5.append(r6);
        r5 = r5.toString();
        r0 = r40;
        r0.add(r5);
        r5 = 2;
        r0 = r26;
        r5 = r0.getString(r5);
        r0 = r52;
        r0.add(r5);
        r5 = 3;
        r0 = r26;
        r5 = r0.getString(r5);
        r0 = r20;
        r0.add(r5);
        r26.moveToNext();
        r22 = r22 + 1;
        goto L_0x040f;
    L_0x0463:
        if (r22 != 0) goto L_0x0473;
    L_0x0465:
        r5 = r64.getBaseContext();
        r6 = "No Students Found";
        r7 = 1;
        r5 = android.widget.Toast.makeText(r5, r6, r7);
        r5.show();
    L_0x0473:
        r63 = new org.apache.poi.hssf.usermodel.HSSFWorkbook;
        r63.<init>();
        r16 = 0;
        r21 = r63.createCellStyle();
        r5 = 50;
        r0 = r21;
        r0.setFillForegroundColor(r5);
        r5 = 1;
        r0 = r21;
        r0.setFillPattern(r5);
        r59 = 0;
        r5 = "Attendance";
        r0 = r63;
        r59 = r0.createSheet(r5);
        r5 = 0;
        r0 = r59;
        r54 = r0.createRow(r5);
        r5 = 1;
        r0 = r59;
        r55 = r0.createRow(r5);
        r5 = 100;
        r0 = new org.apache.poi.ss.usermodel.Row[r5];
        r56 = r0;
        r38 = 0;
    L_0x04ab:
        r5 = r52.size();
        r0 = r38;
        if (r0 >= r5) goto L_0x04c0;
    L_0x04b3:
        r5 = r38 + 2;
        r0 = r59;
        r5 = r0.createRow(r5);
        r56[r38] = r5;
        r38 = r38 + 1;
        goto L_0x04ab;
    L_0x04c0:
        r5 = 0;
        r0 = r54;
        r16 = r0.createCell(r5);
        r5 = "Roll Number";
        r0 = r16;
        r0.setCellValue(r5);
        r5 = 1;
        r0 = r54;
        r16 = r0.createCell(r5);
        r5 = "Att %";
        r0 = r16;
        r0.setCellValue(r5);
        r5 = "SELECT * FROM skcet WHERE register = '";
        r0 = r64;
        r0.qc11 = r5;
        r35 = 0;
    L_0x04e4:
        r5 = r52.size();
        r0 = r35;
        if (r0 >= r5) goto L_0x051c;
    L_0x04ec:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r0 = r64;
        r6 = r0.qc11;
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r5 = r6.append(r5);
        r6 = "'or register = '";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r0 = r64;
        r0.qc11 = r5;
        r35 = r35 + 1;
        goto L_0x04e4;
    L_0x051c:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r0 = r64;
        r6 = r0.qc11;
        r5 = r5.append(r6);
        r6 = "1';";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r0 = r64;
        r0.qc11 = r5;
        r43 = new android.app.ProgressDialog;
        r0 = r43;
        r1 = r64;
        r0.<init>(r1);
        r5 = "Downloading from Server";
        r0 = r43;
        r0.setMessage(r5);
        r43.show();
        r4 = new creations.raghul.smartattendance.alita$13;
        r6 = 1;
        r7 = "http://sraghul.com/wreadcloudat.php";
        r8 = new creations.raghul.smartattendance.alita$11;
        r0 = r64;
        r1 = r43;
        r8.<init>(r1);
        r9 = new creations.raghul.smartattendance.alita$12;
        r0 = r64;
        r1 = r43;
        r9.<init>(r1);
        r5 = r64;
        r4.<init>(r6, r7, r8, r9);
        r5 = r64.getApplicationContext();
        r57 = com.android.volley.toolbox.Volley.newRequestQueue(r5);
        r0 = r57;
        r0.add(r4);
        r35 = 0;
    L_0x0575:
        r5 = r52.size();
        r0 = r35;
        if (r0 >= r5) goto L_0x03fd;
    L_0x057d:
        r29 = new java.util.ArrayList;
        r29.<init>();
        r30 = new java.util.ArrayList;
        r30.<init>();
        r33 = new java.util.ArrayList;
        r33.<init>();
        r15 = new java.util.ArrayList;
        r15.<init>();
        r5 = r56[r35];
        r6 = 0;
        r16 = r5.createCell(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r0 = r16;
        r0.setCellValue(r5);
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM STUDENT WHERE regno = '";
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r5 = r6.append(r5);
        r6 = "'";
        r5 = r5.append(r6);
        r51 = r5.toString();
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM ATTENDANCETEST WHERE register = '";
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r5 = r6.append(r5);
        r6 = "';";
        r5 = r5.append(r6);
        r46 = r5.toString();
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM ATTENDANCETEST WHERE register = '";
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r5 = r6.append(r5);
        r6 = "' AND isPresent = 1";
        r5 = r5.append(r6);
        r47 = r5.toString();
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM ATTENDANCETEST WHERE register = '";
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r5 = r6.append(r5);
        r6 = "' AND isPresent = 2";
        r5 = r5.append(r6);
        r48 = r5.toString();
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r51;
        r27 = r5.execQuery(r0);
        r14 = 0;
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r46;
        r23 = r5.execQuery(r0);
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r47;
        r24 = r5.execQuery(r0);
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r48;
        r25 = r5.execQuery(r0);
        if (r23 != 0) goto L_0x066d;
    L_0x0666:
        r5 = "profile";
        r6 = "cur null";
        android.util.Log.d(r5, r6);
    L_0x066d:
        if (r24 != 0) goto L_0x0676;
    L_0x066f:
        r5 = "profile";
        r6 = "cur1 null";
        android.util.Log.d(r5, r6);
    L_0x0676:
        if (r23 == 0) goto L_0x06d4;
    L_0x0678:
        if (r24 == 0) goto L_0x06d4;
    L_0x067a:
        r23.moveToFirst();
        r24.moveToFirst();
        r5 = r24.getCount();	 Catch:{ Exception -> 0x075d }
        r5 = (float) r5;	 Catch:{ Exception -> 0x075d }
        r6 = r23.getCount();	 Catch:{ Exception -> 0x075d }
        r6 = (float) r6;	 Catch:{ Exception -> 0x075d }
        r5 = r5 / r6;
        r6 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r14 = r5 * r6;
        r5 = 0;
        r5 = (r14 > r5 ? 1 : (r14 == r5 ? 0 : -1));
        if (r5 > 0) goto L_0x0695;
    L_0x0694:
        r14 = 0;
    L_0x0695:
        r5 = 1117126656; // 0x42960000 float:75.0 double:5.51933903E-315;
        r5 = (r14 > r5 ? 1 : (r14 == r5 ? 0 : -1));
        if (r5 >= 0) goto L_0x06b7;
    L_0x069b:
        r5 = r24.getCount();	 Catch:{ Exception -> 0x075d }
        r6 = r25.getCount();	 Catch:{ Exception -> 0x075d }
        r5 = r5 + r6;
        r5 = (float) r5;	 Catch:{ Exception -> 0x075d }
        r6 = r23.getCount();	 Catch:{ Exception -> 0x075d }
        r6 = (float) r6;	 Catch:{ Exception -> 0x075d }
        r5 = r5 / r6;
        r6 = 1120403456; // 0x42c80000 float:100.0 double:5.53552857E-315;
        r14 = r5 * r6;
        r5 = 1117126656; // 0x42960000 float:75.0 double:5.51933903E-315;
        r5 = (r14 > r5 ? 1 : (r14 == r5 ? 0 : -1));
        if (r5 <= 0) goto L_0x06b7;
    L_0x06b5:
        r14 = 1117126656; // 0x42960000 float:75.0 double:5.51933903E-315;
    L_0x06b7:
        r5 = r56[r35];	 Catch:{ Exception -> 0x075d }
        r6 = 1;
        r16 = r5.createCell(r6);	 Catch:{ Exception -> 0x075d }
        r5 = java.lang.Float.toString(r14);	 Catch:{ Exception -> 0x075d }
        r0 = r16;
        r0.setCellValue(r5);	 Catch:{ Exception -> 0x075d }
        r5 = 1117126656; // 0x42960000 float:75.0 double:5.51933903E-315;
        r5 = (r14 > r5 ? 1 : (r14 == r5 ? 0 : -1));
        if (r5 >= 0) goto L_0x06d4;
    L_0x06cd:
        r0 = r16;
        r1 = r21;
        r0.setCellStyle(r1);	 Catch:{ Exception -> 0x075d }
    L_0x06d4:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "SELECT * FROM ATTENDANCETEST WHERE register = '";
        r6 = r5.append(r6);
        r0 = r52;
        r1 = r35;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r6.append(r5);
        r6 = "' order by datex,hour;";
        r5 = r5.append(r6);
        r45 = r5.toString();
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r45;
        r28 = r5.execQuery(r0);
        if (r28 == 0) goto L_0x0707;
    L_0x0701:
        r5 = r28.getCount();
        if (r5 != 0) goto L_0x0762;
    L_0x0707:
        r5 = 0;
        r6 = 7500; // 0x1d4c float:1.051E-41 double:3.7055E-320;
        r0 = r59;
        r0.setColumnWidth(r5, r6);
        r5 = 1;
        r6 = 7500; // 0x1d4c float:1.051E-41 double:3.7055E-320;
        r0 = r59;
        r0.setColumnWidth(r5, r6);
        r53 = android.os.Environment.getExternalStorageDirectory();
        r32 = new java.io.File;
        r5 = "Attendance.xls";
        r0 = r32;
        r1 = r53;
        r0.<init>(r1, r5);
        r41 = 0;
        r42 = new java.io.FileOutputStream;	 Catch:{ IOException -> 0x0879, Exception -> 0x08a0 }
        r0 = r42;
        r1 = r32;
        r0.<init>(r1);	 Catch:{ IOException -> 0x0879, Exception -> 0x08a0 }
        r0 = r63;
        r1 = r42;
        r0.write(r1);	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        r5 = "FileUtils";
        r6 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        r6.<init>();	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        r7 = "Writing file";
        r6 = r6.append(r7);	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        r0 = r32;
        r6 = r6.append(r0);	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        r6 = r6.toString();	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        android.util.Log.w(r5, r6);	 Catch:{ IOException -> 0x09ec, Exception -> 0x09e7, all -> 0x09e2 }
        if (r42 == 0) goto L_0x0757;
    L_0x0754:
        r42.close();	 Catch:{ Exception -> 0x0874 }
    L_0x0757:
        r41 = r42;
    L_0x0759:
        r35 = r35 + 1;
        goto L_0x0575;
    L_0x075d:
        r31 = move-exception;
        r14 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        goto L_0x06d4;
    L_0x0762:
        r29.clear();
        r15.clear();
        r28.moveToFirst();
        r17 = 0;
    L_0x076d:
        r5 = r28.isAfterLast();
        if (r5 != 0) goto L_0x0707;
    L_0x0773:
        r5 = 0;
        r0 = r28;
        r5 = r0.getString(r5);
        r0 = r30;
        r0.add(r5);
        r5 = 1;
        r0 = r28;
        r5 = r0.getInt(r5);
        r5 = java.lang.Integer.valueOf(r5);
        r0 = r33;
        r0.add(r5);
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = 0;
        r0 = r28;
        r6 = r0.getString(r6);
        r5 = r5.append(r6);
        r6 = ":";
        r5 = r5.append(r6);
        r6 = 1;
        r0 = r28;
        r6 = r0.getInt(r6);
        r5 = r5.append(r6);
        r6 = "th Hour";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r0 = r29;
        r0.add(r5);
        r5 = 3;
        r0 = r28;
        r5 = r0.getInt(r5);
        r6 = 1;
        if (r5 != r6) goto L_0x0833;
    L_0x07c9:
        r5 = "p";
        r15.add(r5);
    L_0x07ce:
        r5 = r56[r35];
        r6 = r17 + 2;
        r16 = r5.createCell(r6);
        r0 = r17;
        r5 = r15.get(r0);
        r5 = (java.lang.String) r5;
        r0 = r16;
        r0.setCellValue(r5);
        r0 = r17;
        r5 = r15.get(r0);
        r6 = "a";
        if (r5 != r6) goto L_0x07f4;
    L_0x07ed:
        r0 = r16;
        r1 = r21;
        r0.setCellStyle(r1);
    L_0x07f4:
        if (r35 != 0) goto L_0x082c;
    L_0x07f6:
        r5 = r17 + 2;
        r0 = r54;
        r16 = r0.createCell(r5);
        r0 = r30;
        r1 = r17;
        r5 = r0.get(r1);
        r5 = (java.lang.String) r5;
        r5 = r5.toString();
        r0 = r16;
        r0.setCellValue(r5);
        r5 = r17 + 2;
        r0 = r55;
        r16 = r0.createCell(r5);
        r0 = r33;
        r1 = r17;
        r5 = r0.get(r1);
        r5 = (java.lang.Integer) r5;
        r5 = r5.toString();
        r0 = r16;
        r0.setCellValue(r5);
    L_0x082c:
        r28.moveToNext();
        r17 = r17 + 1;
        goto L_0x076d;
    L_0x0833:
        r5 = 3;
        r0 = r28;
        r5 = r0.getInt(r5);
        r6 = 2;
        if (r5 != r6) goto L_0x0843;
    L_0x083d:
        r5 = "o";
        r15.add(r5);
        goto L_0x07ce;
    L_0x0843:
        r5 = "profile";
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r7 = 0;
        r0 = r28;
        r7 = r0.getString(r7);
        r6 = r6.append(r7);
        r7 = " -> ";
        r6 = r6.append(r7);
        r7 = 3;
        r0 = r28;
        r7 = r0.getInt(r7);
        r6 = r6.append(r7);
        r6 = r6.toString();
        android.util.Log.d(r5, r6);
        r5 = "a";
        r15.add(r5);
        goto L_0x07ce;
    L_0x0874:
        r5 = move-exception;
        r41 = r42;
        goto L_0x0759;
    L_0x0879:
        r31 = move-exception;
    L_0x087a:
        r5 = "FileUtils";
        r6 = new java.lang.StringBuilder;	 Catch:{ all -> 0x08b4 }
        r6.<init>();	 Catch:{ all -> 0x08b4 }
        r7 = "Error writing ";
        r6 = r6.append(r7);	 Catch:{ all -> 0x08b4 }
        r0 = r32;
        r6 = r6.append(r0);	 Catch:{ all -> 0x08b4 }
        r6 = r6.toString();	 Catch:{ all -> 0x08b4 }
        r0 = r31;
        android.util.Log.w(r5, r6, r0);	 Catch:{ all -> 0x08b4 }
        if (r41 == 0) goto L_0x0759;
    L_0x0898:
        r41.close();	 Catch:{ Exception -> 0x089d }
        goto L_0x0759;
    L_0x089d:
        r5 = move-exception;
        goto L_0x0759;
    L_0x08a0:
        r31 = move-exception;
    L_0x08a1:
        r5 = "FileUtils";
        r6 = "Failed to save file";
        r0 = r31;
        android.util.Log.w(r5, r6, r0);	 Catch:{ all -> 0x08b4 }
        if (r41 == 0) goto L_0x0759;
    L_0x08ac:
        r41.close();	 Catch:{ Exception -> 0x08b1 }
        goto L_0x0759;
    L_0x08b1:
        r5 = move-exception;
        goto L_0x0759;
    L_0x08b4:
        r5 = move-exception;
    L_0x08b5:
        if (r41 == 0) goto L_0x08ba;
    L_0x08b7:
        r41.close();	 Catch:{ Exception -> 0x09df }
    L_0x08ba:
        throw r5;
    L_0x08bb:
        r5 = "view";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x08cf;
    L_0x08c5:
        r5 = "attendance";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x08dd;
    L_0x08cf:
        r5 = "Just to Confirm, Please say your roll number";
        r0 = r64;
        r0.text = r5;
        r5 = 202; // 0xca float:2.83E-43 double:1.0E-321;
        r0 = r64;
        r0.f27x = r5;
        goto L_0x00a0;
    L_0x08dd:
        r0 = r64;
        r5 = r0.f27x;
        r6 = 202; // 0xca float:2.83E-43 double:1.0E-321;
        if (r5 != r6) goto L_0x094f;
    L_0x08e5:
        r5 = "Opening for you";
        r0 = r64;
        r0.text = r5;
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "select * from skcet where register = '";
        r5 = r5.append(r6);
        r0 = r37;
        r5 = r5.append(r0);
        r6 = "';";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r0 = r64;
        r0.qc11 = r5;
        r43 = new android.app.ProgressDialog;
        r0 = r43;
        r1 = r64;
        r0.<init>(r1);
        r5 = "Downloading from Server";
        r0 = r43;
        r0.setMessage(r5);
        r43.show();
        r4 = new creations.raghul.smartattendance.alita$16;
        r6 = 1;
        r7 = "http://sraghul.com/wreadcloudat.php";
        r8 = new creations.raghul.smartattendance.alita$14;
        r0 = r64;
        r1 = r43;
        r2 = r37;
        r8.<init>(r1, r2);
        r9 = new creations.raghul.smartattendance.alita$15;
        r0 = r64;
        r1 = r43;
        r9.<init>(r1);
        r5 = r64;
        r4.<init>(r6, r7, r8, r9);
        r5 = r64.getApplicationContext();
        r57 = com.android.volley.toolbox.Volley.newRequestQueue(r5);
        r0 = r57;
        r0.add(r4);
        r5 = 1;
        r0 = r64;
        r0.f27x = r5;
        goto L_0x00a0;
    L_0x094f:
        r5 = "message";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0977;
    L_0x0959:
        r5 = "text";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0977;
    L_0x0963:
        r5 = "sms";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x0977;
    L_0x096d:
        r5 = "messaging";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x099c;
    L_0x0977:
        r5 = "stop";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x098b;
    L_0x0981:
        r5 = "dont";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x099c;
    L_0x098b:
        r39 = "delete from sendmsg;";
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r39;
        r5.execAction(r0);
        r5 = "Sure, Will not send From this Phone alone";
        r0 = r64;
        r0.text = r5;
        goto L_0x00a0;
    L_0x099c:
        r5 = "message";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x09ce;
    L_0x09a6:
        r5 = "text";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x09ce;
    L_0x09b0:
        r5 = "sms";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x09ce;
    L_0x09ba:
        r5 = "messaging";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 != 0) goto L_0x09ce;
    L_0x09c4:
        r5 = "notify";
        r0 = r37;
        r5 = r0.contains(r5);
        if (r5 == 0) goto L_0x00a0;
    L_0x09ce:
        r39 = "insert into sendmsg values(1);";
        r5 = creations.raghul.smartattendance.AppBase.handler;
        r0 = r39;
        r5.execAction(r0);
        r5 = "Sure, From this Phone alone";
        r0 = r64;
        r0.text = r5;
        goto L_0x00a0;
    L_0x09df:
        r6 = move-exception;
        goto L_0x08ba;
    L_0x09e2:
        r5 = move-exception;
        r41 = r42;
        goto L_0x08b5;
    L_0x09e7:
        r31 = move-exception;
        r41 = r42;
        goto L_0x08a1;
    L_0x09ec:
        r31 = move-exception;
        r41 = r42;
        goto L_0x087a;
        */
        throw new UnsupportedOperationException("Method not decompiled: creations.raghul.smartattendance.alita.mainprocess(java.lang.String):java.lang.String");
    }

    void firstuse() {
        this.text = "Welcome, I am Alita, Developed by Raghul. My abilities are limited to attendance in this app but I can still understand both Tamil and English. I suggest you to grant me Permissions in your phone's systemsetting for using Raghul's Neural Networks for audio processing. If not you can still use English audio processing alone using default Google's Voice Indent.";
        MediaPlayer.create(this, C0319R.raw.first).start();
    }
}
