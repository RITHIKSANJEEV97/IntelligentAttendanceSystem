package creations.raghul.smartattendance;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.Toast;
import java.util.ArrayList;

public class AppBase extends AppCompatActivity {
    public static ArrayList<String> Sections;
    public static Activity activity;
    public static ArrayList<String> divisions;
    public static ArrayList<String> groups;
    public static databaseHandler handler;
    gridAdapter adapter;
    ArrayList<String> basicFields;
    GridView gridView;

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(C0319R.menu.mai_menu, menu);
        return true;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.base_layout);
        this.basicFields = new ArrayList();
        handler = new databaseHandler(this);
        activity = this;
        checkforsign();
        getSupportActionBar().show();
        divisions = new ArrayList();
        divisions.add("1st");
        divisions.add("2nd");
        divisions.add("3rd");
        divisions.add("4th");
        divisions.add("5th");
        divisions.add("6th");
        divisions.add("7th");
        divisions.add("8th");
        divisions.add("9th");
        divisions.add("10th");
        divisions.add("11th");
        divisions.add("12th");
        groups = new ArrayList();
        groups.add("IT");
        groups.add("School");
        groups.add("CSE");
        groups.add("MECH");
        groups.add("MCT");
        groups.add("CIVIL");
        groups.add("ECE");
        groups.add("EEE");
        groups.add("MBBS");
        groups.add("MS");
        groups.add("MD");
        groups.add("BCOM");
        groups.add("BBM");
        groups.add("MBA");
        groups.add("ARCH");
        Sections = new ArrayList();
        Sections.add("A");
        Sections.add("B");
        Sections.add("C");
        Sections.add("D");
        Sections.add("E");
        Sections.add("F");
        Sections.add("G");
        this.gridView = (GridView) findViewById(C0319R.id.grid);
        this.basicFields.add("Mark Absenties (Attendance)");
        this.basicFields.add("Skcet To Do List");
        this.basicFields.add("NOTES");
        this.basicFields.add("Artificial Intelligence");
        this.basicFields.add("Students Area");
        this.adapter = new gridAdapter(this, this.basicFields, this);
        this.gridView.setAdapter(this.adapter);
    }

    void checkforsign() {
        try {
            Cursor ccr = handler.execQuery("select * from acc;");
            ccr.moveToFirst();
            if (ccr.isAfterLast() || ccr.getString(1).equals("")) {
                startActivity(new Intent(this, alita.class));
            }
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), 1).show();
        }
    }

    public void loadSettings(MenuItem item) {
        startActivity(new Intent(this, SettingsActivity.class));
    }

    public void loadAbout(MenuItem item) {
        startActivity(new Intent(this, About.class));
    }
}
