package creations.raghul.smartattendance;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class noteActivity extends AppCompatActivity implements OnItemClickListener, OnItemLongClickListener {
    static final /* synthetic */ boolean $assertionsDisabled = (!noteActivity.class.desiredAssertionStatus());
    Activity activity = this;
    ArrayAdapter adapter;
    ArrayList contents;
    ListView listView;
    ArrayList titles;

    class C03631 implements OnClickListener {
        C03631() {
        }

        public void onClick(View view) {
            noteActivity.this.startActivity(new Intent(noteActivity.this.activity, noteCreate.class));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_note);
        this.titles = new ArrayList();
        this.contents = new ArrayList();
        FloatingActionButton fab = (FloatingActionButton) findViewById(C0319R.id.fab_Note);
        if ($assertionsDisabled || fab != null) {
            fab.setOnClickListener(new C03631());
            this.listView = (ListView) findViewById(C0319R.id.noteList);
            loadNotes();
            this.listView.setOnItemClickListener(this);
            this.listView.setOnItemLongClickListener(this);
            return;
        }
        throw new AssertionError();
    }

    private void loadNotes() {
        this.titles.clear();
        this.contents.clear();
        Cursor cursor = AppBase.handler.execQuery("SELECT * FROM NOTES");
        if (cursor == null || cursor.getCount() == 0) {
            Toast.makeText(getBaseContext(), "No Notes Found", 1).show();
            return;
        }
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            this.titles.add(cursor.getString(0));
            this.contents.add(cursor.getString(1));
            cursor.moveToNext();
        }
        this.adapter = new ArrayAdapter(this, 17367043, this.titles);
        this.listView.setAdapter(this.adapter);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(C0319R.menu.note_menu, menu);
        return true;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        Builder alert = new Builder(this.activity);
        alert.setTitle(this.titles.get(position).toString());
        alert.setMessage(this.contents.get(position).toString());
        alert.setPositiveButton("OK", null);
        alert.show();
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
        Builder alert = new Builder(this.activity);
        final String title = this.titles.get(position).toString();
        final String body = this.contents.get(position).toString();
        alert.setTitle("Delete ?");
        alert.setMessage("Do you want to delete this note ?");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (AppBase.handler.execAction("DELETE FROM NOTES WHERE TITLE = '" + title + "' AND body = '" + body + "'")) {
                    noteActivity.this.loadNotes();
                    Toast.makeText(noteActivity.this.getBaseContext(), "Deleted", 1).show();
                } else {
                    noteActivity.this.loadNotes();
                    Toast.makeText(noteActivity.this.getBaseContext(), "Failed", 1).show();
                }
                dialog.dismiss();
            }
        });
        alert.setNegativeButton("No", null);
        alert.show();
        return true;
    }

    public void refreshNote(MenuItem item) {
        loadNotes();
    }
}
