package creations.raghul.smartattendance;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Edit_Student extends AppCompatActivity {
    static final /* synthetic */ boolean $assertionsDisabled = (!Edit_Student.class.desiredAssertionStatus());
    Activity activity = this;

    class C03171 implements OnClickListener {
        static final /* synthetic */ boolean $assertionsDisabled = (!Edit_Student.class.desiredAssertionStatus());

        C03171() {
        }

        public void onClick(View v) {
            Cursor cr = AppBase.handler.execQuery("SELECT * FROM STUDENT WHERE regno = '" + ((EditText) Edit_Student.this.findViewById(C0319R.id.register_)).getText().toString().toUpperCase() + "'");
            if (cr == null || cr.getCount() == 0) {
                Toast.makeText(Edit_Student.this.getBaseContext(), "No Such Student", 1).show();
                return;
            }
            cr.moveToFirst();
            try {
                EditText name = (EditText) Edit_Student.this.findViewById(C0319R.id.edit_name_);
                EditText roll = (EditText) Edit_Student.this.findViewById(C0319R.id.roll_);
                EditText contact = (EditText) Edit_Student.this.findViewById(C0319R.id.contact_);
                if ($assertionsDisabled || name != null) {
                    name.setText(cr.getString(0));
                    if ($assertionsDisabled || roll != null) {
                        roll.setText(cr.getString(4));
                        if ($assertionsDisabled || contact != null) {
                            contact.setText(cr.getString(3));
                            return;
                        }
                        throw new AssertionError();
                    }
                    throw new AssertionError();
                }
                throw new AssertionError();
            } catch (Exception e) {
            }
        }
    }

    class C03182 implements OnClickListener {
        C03182() {
        }

        public void onClick(View v) {
            String qu = "UPDATE STUDENT SET name = '" + ((EditText) Edit_Student.this.findViewById(C0319R.id.edit_name_)).getText().toString() + "' ,  roll = " + ((EditText) Edit_Student.this.findViewById(C0319R.id.roll_)).getText().toString() + " , contact = '" + ((EditText) Edit_Student.this.findViewById(C0319R.id.contact_)).getText().toString() + "' WHERE regno = '" + ((EditText) Edit_Student.this.findViewById(C0319R.id.register_)).getText().toString().toUpperCase() + "'";
            Log.d("Edit_Student", qu);
            if (AppBase.handler.execAction(qu)) {
                Toast.makeText(Edit_Student.this.getBaseContext(), "Edit Saved", 1).show();
                Edit_Student.this.activity.finish();
                return;
            }
            Toast.makeText(Edit_Student.this.getBaseContext(), "Error Occured", 1).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0319R.layout.activity_edit__student);
        Button loadButton = (Button) findViewById(C0319R.id.loadForEdit);
        if ($assertionsDisabled || loadButton != null) {
            loadButton.setOnClickListener(new C03171());
            Button saveEdit = (Button) findViewById(C0319R.id.buttonSAVEEDITS);
            if ($assertionsDisabled || saveEdit != null) {
                saveEdit.setOnClickListener(new C03182());
                return;
            }
            throw new AssertionError();
        }
        throw new AssertionError();
    }
}
