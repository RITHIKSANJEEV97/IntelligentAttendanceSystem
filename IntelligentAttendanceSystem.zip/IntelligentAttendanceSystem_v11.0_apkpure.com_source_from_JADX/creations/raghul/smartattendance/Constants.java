package creations.raghul.smartattendance;

public class Constants {
    public static final String ROOT_URL = "http://sraghul.com/";
    public static int check = 5;
    public static final String urlr = "http://sraghul.com/wreadcloudat.php";
    public static final String urlw = "http://sraghul.com/writecloudat.php";
}
