package creations.raghul.smartattendance;

public final class BuildConfig {
    public static final String APPLICATION_ID = "creations.raghul.smartattendance";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 11;
    public static final String VERSION_NAME = "11.0";
}
